#include "proxy.h"
#include <stdio.h>

void msg_map::Proxy::Execute(const char* cmd, const char* log, const char* mode)
{
#ifndef BUF_MAX
#define BUF_MAX				1024
#endif
    printf("start Execute!\n");
    FILE* fpin, * fout;
    char line[BUF_MAX];
    
    if((fout = fopen(log, mode)) == NULL){
	printf("Open log<%s> error\n", log);
	return;
    }
    printf("open log\n");
    
    fputs("\n#", fout);
    fputs(cmd, fout);
    
    if((fpin = popen(cmd, "r")) == NULL){
	printf("Popen error!\n"); 
	return;
    }
    
    while(fgets(line, BUF_MAX, fpin) != NULL){
	fputs(line, fout);
	
    }
    
    if(pclose(fpin) == -1){
	printf("Pclose error!\n");
    }
    fclose(fout);
    
#undef BUF_MAX
}

//@ wls
bool msg_map::Proxy::ExecuteCmd(const char* cmd , FILE** fpin)
{
    printf("start ExecuteCmd!\n");
    if((*fpin = popen(cmd, "r")) == NULL){
	printf("Popen error!\n");
	return false;
    }
    return true;
}
//@ wls
