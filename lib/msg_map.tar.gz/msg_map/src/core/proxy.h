#ifndef PROXY_H__
#define PROXY_H__

#include <queue>
#include "thread.h"

namespace msg_map{
    
    

struct data{
    char* line;
};

// #define a

class Proxy
{
friend class MessageMapThreadApplication;
    
private:
    Proxy(){}
    ~Proxy(){}
    
public:
    void Execute(const char* cmd, const char* log, const char* mode = "w");
    //@ wls
    bool ExecuteCmd(const char* cmd , FILE** fpin); 
    //@ wls
}; 
    
}

#endif